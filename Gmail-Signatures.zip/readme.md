Blank Canvas Signatures for Gmail
============================

This extension for [Firefox](https://addons.mozilla.org/en-US/firefox/addon/blank-canvas-gmail-signatures/) and [Google Chrome](https://chrome.google.com/webstore/detail/ijdoblggemelaimffjccmdbmodlppofd) automatically inserts HTML signatures into your Gmail messages based on which address you are sending from. 

**[Report Bugs or Suggest Features](https://gmailsignatures.uservoice.com/forums/164833)**

This project is **developed and maintained as a hobby** by [Jerome Dane](https://profiles.google.com/JeromeDane). Please remember that all other “real life” obligations must come first. I’d rather be at the pool with my family than fixing bugs in software I write and distribute for free.

Google frequently changes the code and layout of Gmail, so this project may be abandoned or fall into disrepair at any time, but you can show your support and help keep it going by [Donating through PayPal](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=B53CJ57ZDZZJC). ♥

